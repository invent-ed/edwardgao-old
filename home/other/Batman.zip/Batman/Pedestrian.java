public class Pedestrian extends Person{

	public Pedestrian(int range) {
		super(range);
		threatLevel = 1;
	}

}
